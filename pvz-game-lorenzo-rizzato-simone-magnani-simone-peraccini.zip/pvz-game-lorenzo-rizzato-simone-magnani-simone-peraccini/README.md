# Plants vs Zombies #

This is a simple remake of the famous tower-defense game. It was developed in Java as a final project for our Object-Oriented Programming course.

### Features ###

+ Story mode: defeat a series of levels of increasing difficulty and unlock new plants
+ Arcade mode: hold out against infinite zombie hordes
+ Track down your Arcade highscores
+ Create multiple player profiles and save your progress

### Developed by: ###

+ Lorenzo Rizzato
+ Simone Magnani
+ Simone Peraccini