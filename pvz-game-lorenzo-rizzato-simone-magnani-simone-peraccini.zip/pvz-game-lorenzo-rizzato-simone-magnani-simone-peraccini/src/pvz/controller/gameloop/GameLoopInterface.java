package pvz.controller.gameloop;
/**
 * Basic GameLoop interface.
 */
public interface GameLoopInterface extends GameLoopProxy {

}
